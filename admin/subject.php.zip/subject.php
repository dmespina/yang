<?php 
session_start();
if (isset($_SESSION['admin_id']) && isset($_SESSION['role']) && $_SESSION['role'] == 'Admin') {
    include "../DB_connection.php";
    include "data/subject.php";
    include "data/grade.php";
    
    $subjects = getAllSubjects($conn);
    $grades = getAllGrades($conn);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Handle form submission for adding a new subject
        $subject_name = $_POST['subject_name'];
        $subject_code = $_POST['subject_code'];
        $grade_id = $_POST['grade'];

        // Validate inputs
        if (empty($subject_name) || empty($subject_code) || empty($grade_id)) {
            $error = 'All fields are required.';
        } else {
            // Insert new subject
            $query = "INSERT INTO subjects (subject, subject_code, grade) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($query);
            if ($stmt->execute([$subject_name, $subject_code, $grade_id])) {
                $success = 'Subject added successfully.';
                // Refresh the subjects list
                $subjects = getAllSubjects($conn);
            } else {
                $error = 'Failed to add subject.';
            }
        }
    }
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin - Subjects</title>
        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="../css/style.css">
        <link rel="icon" href="../logo.png">
        <!-- Bootstrap Icons -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
        <!-- SweetAlert2 CDN -->
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <style>
            body {
                font-family: 'Poppins', sans-serif;
                background-color: #f4f6f9;
            }
            .navbar {
                background: linear-gradient(45deg, #007bff, #6c5ce7);
                border-bottom: 3px solid #f1f1f1;
            }
            .navbar-brand {
                font-weight: 600;
                color: #fff;
            }
            #sidebar {
                background: #2d3436;
                color: #fff;
                min-height: 100vh;
            }
            .sidebar a {
                color: #b2bec3;
                transition: color 0.2s ease;
            }
            .sidebar a:hover {
                color: #fff;
            }
            .card {
                border: none;
                border-radius: 10px;
                overflow: hidden;
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }
            .card:hover {
                transform: translateY(-5px);
                box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            }
            .card-header {
                font-weight: 500;
                background: #6c5ce7;
                border-bottom: 2px solid #f1f1f1;
                border-radius: 0;
            }
            .btn-dark {
                background-color: #6c5ce7;
                border-color: #6c5ce7;
                transition: background-color 0.3s ease;
            }
            .btn-dark:hover {
                background-color: #4b4c72;
            }
            .btn-warning {
                background-color: #f39c12;
                border-color: #f39c12;
            }
            .btn-warning:hover {
                background-color: #e67e22;
            }
            .btn-danger {
                background-color: #e74c3c;
                border-color: #e74c3c;
            }
            .btn-danger:hover {
                background-color: #c0392b;
            }
            .table-responsive {
                margin-top: O.1px;
            }
            .table thead th {
                background-color: #6c5ce7;
                color: #fff;
            }
            .table tbody tr:hover {
                background-color: #f1f1f1;
            }
            .modal-content {
                border-radius: 10px;
            }
        </style>
    </head>
    <body>
        <!-- Header -->
        <header class="navbar navbar-expand-lg navbar-light shadow-sm">
            <div class="container-fluid">
                <!-- Sidebar Toggle Button -->
                <button class="btn btn-light me-2" id="sidebarToggle" type="button">
                    <i class="bi bi-list"></i>
                </button>
                <!-- Title -->
                <a class="navbar-brand" href="#">Admin Dashboard</a>
                <!-- Profile Section -->
                <div class="dropdown ms-auto">
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="../profile.png" alt="profile" width="32" height="32" class="rounded-circle me-2">
                        <span><?php echo $_SESSION['username']; ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="profileDropdown">
                        <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                    </ul>
                </div>
            </div>
        </header>

        <div class="d-flex">
            <!-- Sidebar -->
            <nav id="sidebar" class="bg-dark p-3 sidebar">
                <ul class="nav flex-column">
                    <li class="nav-item mb-2"><a href="index.php" class="nav-link text-white"><i class="bi bi-house-door"></i> Dashboard</a></li>
                    <li class="nav-item mb-2"><a href="teacher.php" class="nav-link text-white"><i class="bi bi-person-badge"></i> Teachers</a></li>
                    <li class="nav-item mb-2"><a href="student.php" class="nav-link text-white"><i class="bi bi-mortarboard"></i> Students</a></li>
                    <li class="nav-item mb-2"><a href="class.php" class="nav-link text-white"><i class="bi bi-box"></i> Class</a></li>
                    <li class="nav-item mb-2"><a href="section.php" class="nav-link text-white"><i class="bi bi-layout-sidebar"></i> Section</a></li>
                    <li class="nav-item mb-2"><a href="grade.php" class="nav-link text-white"><i class="bi bi-bar-chart-steps"></i> Grade</a></li>
                    <li class="nav-item mb-2"><a href="subject.php" class="nav-link text-white active"><i class="bi bi-book"></i> Subjects</a></li>
                    <li class="nav-item mb-2"><a href="message.php" class="nav-link text-white"><i class="bi bi-envelope"></i> Message</a></li>
                    <li class="nav-item mb-2"><a href="events.php" class="nav-link text-white"><i class="bi bi-calendar-event"></i> Events</a></li>
                    <li class="nav-item mb-2"><a href="settings.php" class="nav-link text-white"><i class="bi bi-gear"></i> Settings</a></li>
                    <li class="nav-item mt-auto">
                        <a href="../logout.php" class="nav-link text-warning"><i class="bi bi-box-arrow-right"></i> Logout</a>
                    </li>
                </ul>
            </nav>

    <!-- Main Content -->
    <div class="container-fluid p-4">
    <h2 class="text-dark mb-4">Subject Management</h2>

    <!-- Add New Subject Modal -->
    <div class="modal fade" id="addSubjectModal" tabindex="-1" aria-labelledby="addSubjectModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addSubjectModalLabel">Add New Subject</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="post" id="addSubjectForm">
                        <div class="mb-3">
                            <label class="form-label">Subject Name</label>
                            <input type="text" class="form-control" name="subject_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Subject Code</label>
                            <input type="text" class="form-control" name="subject_code" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Grade</label>
                            <select name="grade" class="form-control" required>
                                <?php foreach ($grades as $grade) { ?>
                                    <option value="<?= htmlspecialchars($grade['grade_id']) ?>">
                                        <?= htmlspecialchars($grade['grade_code'].'-'.$grade['grade']) ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-dark">Add Subject</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <!-- Button trigger modal -->
    <button type="button" class="btn btn-dark mb-4" data-bs-toggle="modal" data-bs-target="#addSubjectModal">
        Add New Subject
    </button>

    <?php if (isset($_GET['error'])) { ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: '<?= htmlspecialchars($_GET['error']) ?>',
            });
        </script>
    <?php } ?>

    <?php if (isset($_GET['success'])) { ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: '<?= htmlspecialchars($_GET['success']) ?>',
            });
        </script>
    <?php } ?>

    <!-- Subjects Table -->
    <div class="table-responsive">
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Subject</th>
                    <th scope="col">Subject Code</th>
                    <th scope="col">Grade</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 0; foreach ($subjects as $subject) { 
                    $i++;  
                ?>
                <tr>
                    <th scope="row"><?= $i ?></th>
                    <td><?= htmlspecialchars($subject['subject']) ?></td>
                    <td><?= htmlspecialchars($subject['subject_code']) ?></td>
                    <td>
                        <?php 
                            $grade = getGradeById($subject['grade'], $conn);
                            echo htmlspecialchars($grade['grade_code'].'-'.$grade['grade']);
                        ?>
                    </td>
                    <td>
                        <a href="subject-edit.php?subject_id=<?= $subject['subject_id'] ?>" class="btn btn-warning">Edit</a>
                        <a href="#" onclick="confirmDelete(<?= $subject['subject_id'] ?>)" class="btn btn-danger">Delete</a>
                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <?php if (empty($subjects)) { ?>
        <div class="alert alert-info mt-3" role="alert">
            No subjects found.
        </div>
    <?php } ?>
</div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('sidebarToggle').addEventListener('click', function () {
            document.getElementById('sidebar').classList.toggle('d-none');
        });

        function confirmDelete(subjectId) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'Cancel'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'subject-delete.php?subject_id=' + subjectId;
                }
            });
        }
        document.getElementById('sidebarToggle').addEventListener('click', function () {
        document.getElementById('sidebar').classList.toggle('d-none');
    });

    function confirmDelete(subjectId) {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'subject-delete.php?subject_id=' + subjectId;
            }
        });
    }

    document.getElementById('addSubjectForm').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

        var formData = new FormData(this);

        fetch('', {
            method: 'POST',
            body: formData
        }).then(response => response.text())
          .then(data => {
              if (data.includes('Subject added successfully.')) {
                  // Close the modal
                  var myModal = bootstrap.Modal.getInstance(document.getElementById('addSubjectModal'));
                  myModal.hide();
                  
                  // Optionally reload the page or update the subjects list
                  location.reload(); // or update the subjects list dynamically
              } else {
                  // Show an error message
                  Swal.fire({
                      icon: 'error',
                      title: 'Error',
                      text: data
                  });
              }
          }).catch(error => console.error('Error:', error));
    });
    </script>
</body>
</html>
<?php 
} else {
    header("Location: ../login.php");
    exit;
} 
?>
